"use strict";
exports.id = 1840;
exports.ids = [1840];
exports.modules = {

/***/ 1840:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ context_useStore)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/context/Store.js

const Store_Store = ()=>{
    const { 0: showLoginRegister , 1: setShowLoginRegister  } = useState(false);
    const { 0: alert , 1: setAlert  } = useState({
        msg: "",
        type: ""
    });
    const { 0: showSideMenu , 1: setShowSideMenu  } = useState(false);
    const { 0: categoryMenu , 1: setCategoryMenu  } = useState(null);
    const { 0: showSideBar , 1: setShowSideBar  } = useState(false);
    const { 0: userLoading , 1: setUserLoading  } = useState(true);
    const { 0: ipAdress , 1: setIpAddress  } = useState(null);
    const { 0: siteInfo , 1: setSiteInfo  } = useState(null);
    const { 0: loading , 1: setLoading  } = useState(false);
    const { 0: update , 1: setUpdate  } = useState(false);
    const { 0: error , 1: setError  } = useState(false);
    const { 0: user , 1: setUser  } = useState(null);
    const { 0: redirect , 1: setRedirect  } = useState("/");
    useEffect(()=>{
        (async ()=>{
            try {
                const token = localStorage.getItem("token");
                if (token) {
                    const res = await fetch(`/api/login?token=${token}`);
                    const result = await res.json();
                    if (res.ok) {
                        setUser(result.user);
                        localStorage.setItem("token", result.token);
                    } else throw result;
                }
            } catch (error) {
                setUser(null);
                localStorage.removeItem("token");
            }
            setUserLoading(false);
        })();
    }, [
        update
    ]); //till;
    async function getIpAddress() {
        try {
            const res = await fetch(`https://geolocation-db.com/json/${"89eb4d70-4cbe-11ed-a0f2-51b843ebe8d7"}`);
            if (res.ok) {
                const result = await res.json();
                setIpAddress(result.IPv4);
                return {
                    error: false,
                    ipAdress: result.IPv4
                };
            }
        } catch (error) {
            return {
                error: true,
                ipAdress: null
            };
        }
    }
    async function updateVisitor(ipAdress) {
        try {
            const res = await fetch("/api/news/dashboard", {
                method: "PUT",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify({
                    ipAdress
                })
            });
            const result = await res.json();
            if (!res.ok) throw result;
        } catch (error) {
            console.log(error.message);
        }
    }
    useEffect(()=>{
        (async ()=>{
            const { error , ipAdress  } = await getIpAddress();
            if (!error) {
                await updateVisitor(ipAdress);
            }
        })();
    }, []);
    useEffect(()=>{
        const controller = new AbortController();
        const signal = controller.signal;
        (async ()=>{
            //fetch siteinfo and settings;
            await getSiteInfo(signal);
            //fetch category menus;
            await getMenus(signal);
        })();
        return ()=>{
            controller.abort();
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        update
    ]);
    async function getSiteInfo(signal) {
        try {
            const res = await fetch("/api/settings", {
                signal
            });
            const result = await res.json();
            if (res.ok) setSiteInfo(result);
            else throw result;
        } catch (error) {}
    }
    async function getMenus(signal) {
        try {
            const res = await fetch("/api/menus", {
                signal
            });
            const result = await res.json();
            if (res.ok) setCategoryMenu(result);
            else throw result;
        } catch (error) {
            setError(true);
        }
    }
    return {
        showLoginRegister,
        setShowLoginRegister,
        user,
        setUser,
        alert,
        setAlert,
        showSideMenu,
        setShowSideMenu,
        showSideBar,
        setShowSideBar,
        error,
        setError,
        siteInfo,
        setUpdate,
        categoryMenu,
        loading,
        setLoading,
        ipAdress,
        userLoading,
        redirect,
        setRedirect
    };
};
/* harmony default export */ const context_Store = ((/* unused pure expression or super */ null && (Store_Store)));

;// CONCATENATED MODULE: ./components/context/StoreProvider.js



const Context = /*#__PURE__*/ (0,external_react_.createContext)(null);
const StoreProvider = ({ children  })=>{
    const store = Store();
    return /*#__PURE__*/ _jsx(Context.Provider, {
        value: store,
        children: children
    });
};
/* harmony default export */ const context_StoreProvider = ((/* unused pure expression or super */ null && (StoreProvider)));

;// CONCATENATED MODULE: ./components/context/useStore.js


const useStore = ()=>{
    return (0,external_react_.useContext)(Context);
};
/* harmony default export */ const context_useStore = (useStore);


/***/ })

};
;