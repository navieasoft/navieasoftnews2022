"use strict";
exports.id = 4474;
exports.ids = [4474];
exports.modules = {

/***/ 4474:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home_AtHome)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./services/client/carusalSetting.js
const carusalSetting = {
    superLargeDesktop: {
        breakpoint: {
            max: 4000,
            min: 3000
        },
        items: 7
    },
    desktop: {
        breakpoint: {
            max: 3000,
            min: 1024
        },
        items: 5
    },
    tablet: {
        breakpoint: {
            max: 1024,
            min: 464
        },
        items: 3
    },
    mobile: {
        breakpoint: {
            max: 464,
            min: 0
        },
        items: 1
    }
};
/* harmony default export */ const client_carusalSetting = (carusalSetting);

// EXTERNAL MODULE: external "react-multi-carousel"
var external_react_multi_carousel_ = __webpack_require__(5804);
var external_react_multi_carousel_default = /*#__PURE__*/__webpack_require__.n(external_react_multi_carousel_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/home/AtHome.js
/* eslint-disable @next/next/no-img-element */ 




const AtHome = ({ data  })=>{
    if (!data) return null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "px-5 lg:px-10 my-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "mb-3",
                children: "At Home"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((external_react_multi_carousel_default()), {
                autoPlay: true,
                infinite: true,
                autoPlaySpeed: 10000,
                transitionDuration: 0,
                draggable: true,
                responsive: client_carusalSetting,
                children: data.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/details?id=${item.id}`,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: "flex flex-col hover:text-gray-500 mx-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "object-cover object-center",
                                    src: `assets/${item.image}`,
                                    alt: ""
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-medium",
                                    children: item.headline
                                })
                            ]
                        })
                    }, item.id))
            })
        ]
    });
};
/* harmony default export */ const home_AtHome = (AtHome);


/***/ })

};
;