"use strict";
exports.id = 1394;
exports.ids = [1394];
exports.modules = {

/***/ 1394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_PoliticsBusiness__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4125);



const BusinessHighlight = ({ data  })=>{
    if (!data) return null;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_PoliticsBusiness__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        data: data
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BusinessHighlight);


/***/ })

};
;