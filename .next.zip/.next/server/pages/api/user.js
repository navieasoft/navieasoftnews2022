"use strict";
(() => {
var exports = {};
exports.id = 5541;
exports.ids = [5541];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 2512:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _services_server_user_user__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6791);

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            (0,_services_server_user_user__WEBPACK_IMPORTED_MODULE_0__/* .getUser */ .PR)(req, res);
            break;
        case "POST":
            (0,_services_server_user_user__WEBPACK_IMPORTED_MODULE_0__/* .addUser */ .cn)(req, res);
            break;
        case "PUT":
            (0,_services_server_user_user__WEBPACK_IMPORTED_MODULE_0__/* .updateUser */ .Nq)(req, res);
            break;
        case "DELETE":
            (0,_services_server_user_user__WEBPACK_IMPORTED_MODULE_0__/* .deleteuser */ .pl)(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2217,6791], () => (__webpack_exec__(2512)));
module.exports = __webpack_exports__;

})();