"use strict";
(() => {
var exports = {};
exports.id = 654;
exports.ids = [654];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 8254:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _services_server_errorhandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6284);
/* harmony import */ var _services_server_multer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5882);
/* harmony import */ var _services_server_user_user__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6791);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _services_server_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2217);






const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getAds(res);
            break;
        case "POST":
            postAds(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}
async function getAds(res) {
    try {
        const data1 = {
            home: {},
            other: {}
        };
        const sql = "SELECT * FROM ads";
        const result = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_4__/* .queryDocument */ .zx)(sql);
        data1.home.small = result.filter((item)=>item.page === "home" && item.size === "small");
        data1.home.long = result.filter((item)=>item.page === "home" && item.size === "long");
        data1.other.small = result.filter((item)=>item.page === "other" && item.size === "small");
        data1.other.long = result.filter((item)=>item.page === "other" && item.size === "long");
        res.send(data1);
    } catch (error) {
        (0,_services_server_errorhandler__WEBPACK_IMPORTED_MODULE_5__/* .errorHandler */ .P)(res, {
            msg: error.message,
            status: error.status || 500
        });
    }
}
async function postAds(req, res) {
    try {
        const { error  } = await (0,_services_server_multer__WEBPACK_IMPORTED_MODULE_0__/* .multipleBodyParser */ .L)(req, res, "ads", [
            {
                name: "image",
                maxCount: 1
            }, 
        ]);
        if (error) throw {
            message: "error occured when image uploading"
        };
        //user virify;
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,_services_server_user_user__WEBPACK_IMPORTED_MODULE_1__/* .userVarification */ .yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId; //till;
        let data1 = "";
        if (req.body.link) data1 += `link = '${req.body.link}'`;
        if (req.files.image) data1 += `, image = '${req.files.image[0].filename}'`;
        const sql = `UPDATE ads SET ${data1} WHERE id = '${req.query.id}'`;
        const result = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_4__/* .queryDocument */ .zx)(sql);
        if (result.affectedRows > 0) {
            if (req.body.exist && req.files.image) {
                fs__WEBPACK_IMPORTED_MODULE_3___default().unlinkSync(path__WEBPACK_IMPORTED_MODULE_2___default().join(process.cwd(), "public", "ads", req.body.exist));
            }
            res.send({
                message: "Updated successfully"
            });
        } else throw {
            message: "Unable to update"
        };
    } catch (error1) {
        fs__WEBPACK_IMPORTED_MODULE_3___default().unlinkSync(path__WEBPACK_IMPORTED_MODULE_2___default().join(process.cwd(), "public", "ads", data.adImg));
        (0,_services_server_errorhandler__WEBPACK_IMPORTED_MODULE_5__/* .errorHandler */ .P)(res, {
            msg: error1.message,
            status: error1.status || 500
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2217,6791], () => (__webpack_exec__(8254)));
module.exports = __webpack_exports__;

})();