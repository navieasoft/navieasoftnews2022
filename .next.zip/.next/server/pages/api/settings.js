"use strict";
(() => {
var exports = {};
exports.id = 8518;
exports.ids = [8518];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 7016:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/server/user/user.js
var user = __webpack_require__(6791);
// EXTERNAL MODULE: ./services/server/errorhandler.js
var errorhandler = __webpack_require__(6284);
// EXTERNAL MODULE: ./services/server/multer.js
var multer = __webpack_require__(5882);
// EXTERNAL MODULE: ./services/server/common.js + 1 modules
var common = __webpack_require__(2217);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(1017);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
// EXTERNAL MODULE: external "fs"
var external_fs_ = __webpack_require__(7147);
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_);
;// CONCATENATED MODULE: ./services/server/settings/siteInfo.js






async function getSiteInfo(req, res) {
    try {
        const result = await (0,common/* queryDocument */.zx)("SELECT * FROM site_info");
        res.send(result[0]);
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function postSiteInfo(req, res) {
    try {
        const { error  } = await (0,multer/* multipleBodyParser */.L)(req, res, "", [
            {
                name: "logo",
                maxCount: 1
            },
            {
                name: "favicon",
                maxCount: 1
            }, 
        ]);
        if (error) throw error || "Error occour when file uploading";
        //user virify;
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId; //till;
        if (req.files) {
            if (req.files.logo) {
                req.body.logo = req.files.logo[0].filename;
                external_fs_default().unlinkSync(external_path_default().join(process.cwd(), "public", req.body.existedLogo));
                delete req.body.existedLogo;
            }
            if (req.files.favicon) req.body.favicon = req.files.favicon[0].filename;
        }
        let data = "";
        Object.entries(req.body).forEach(([key, value])=>{
            if (value) {
                if (data) {
                    data += `, ${key} = '${value}'`;
                } else data += `${key} = '${value}'`;
            }
        });
        const sql = `UPDATE site_info SET ${data} WHERE id = '1'`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (result.changedRows > 0) {
            res.send({
                message: "Updated successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to update, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}

;// CONCATENATED MODULE: ./pages/api/settings/index.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getSiteInfo(req, res);
            break;
        case "POST":
            postSiteInfo(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2217,6791], () => (__webpack_exec__(7016)));
module.exports = __webpack_exports__;

})();